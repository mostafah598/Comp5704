#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <math.h>
#include <map>
#include <omp.h>
#include "/lib/x86_64-linux-gnu/openmpi/include/mpi.h"
#include <x86intrin.h>
#include <bmiintrin.h>
#include <chrono>
using namespace std;
using namespace std::chrono;

#define MAX_WORD_LENGTH 16

/* Reads data in 64MB chunks */
#define CHUNK_SIZE (128*1024*1024)
#define TRUE 1
#define FALSE 0

#define	FORCE_INLINE inline __attribute__((always_inline))

inline uint32_t rotl32 ( uint32_t x, int8_t r )
{
  return (x << r) | (x >> (32 - r));
}

uint32_t rotl32 ( uint32_t x, int8_t r ); /* instantiation */

#define	ROTL32(x,y)	rotl32(x,y)

//-----------------------------------------------------------------------------
// Block read - if your platform needs to do endian-swapping or can only
// handle aligned reads, do the conversion here

FORCE_INLINE uint32_t getblock32 ( const uint32_t * p, int i )
{
  return p[i];
}

//-----------------------------------------------------------------------------
// Finalization mix - force all bits of a hash block to avalanche

FORCE_INLINE uint32_t fmix32 ( uint32_t h )
{
  h ^= h >> 16;
  h *= 0x85ebca6b;
  h ^= h >> 13;
  h *= 0xc2b2ae35;
  h ^= h >> 16;

  return h;
}

//-----------------------------------------------------------------------------

void MurmurHash3_x86_32 ( const void * key, int len,
                          uint32_t seed, void * out )
{
  const uint8_t * data = (const uint8_t*)key;
  const int nblocks = len / 4;

  uint32_t h1 = seed;

  const uint32_t c1 = 0xcc9e2d51;
  const uint32_t c2 = 0x1b873593;

  //----------
  // body

  const uint32_t * blocks = (const uint32_t *)(data + nblocks*4);

  for(int i = -nblocks; i; i++)
  {
    uint32_t k1 = getblock32(blocks,i);

    k1 *= c1;
    k1 = ROTL32(k1,15);
    k1 *= c2;
    
    h1 ^= k1;
    h1 = ROTL32(h1,13); 
    h1 = h1*5+0xe6546b64;
  }

  //----------
  // tail

  const uint8_t * tail = (const uint8_t*)(data + nblocks*4);

  uint32_t k1 = 0;

  switch(len & 3)
  {
  case 3: k1 ^= tail[2] << 16;
  case 2: k1 ^= tail[1] << 8;
  case 1: k1 ^= tail[0];
          k1 *= c1; k1 = ROTL32(k1,15); k1 *= c2; h1 ^= k1;
  };

  //----------
  // finalization

  h1 ^= len;

  h1 = fmix32(h1);

  *(uint32_t*)out = h1;
} 

/* Details about the API are given in HashFunction.h */
/* Note: this function uses VLA (Variable Length Array)*/
unsigned gethash( const char* word, char hash_rand, unsigned log2range)
{
  unsigned hash;
  uint32_t seed = 0x9747b28c;
  size_t len = strlen( word ) + 1;
  char str_to_hash[len];
  strcpy( str_to_hash, word ) ;
  /* hash_rand is hash function specific random value, 
   * we put it at the end of the string */
  str_to_hash[len-1] = hash_rand;
  MurmurHash3_x86_32( str_to_hash, len*sizeof(char), seed, &hash );
  /* Now, we shift bits to limit the 
   * hash value  within log2range */
  hash = hash << (32 - log2range);
  hash = hash >> (32 - log2range);
  return hash;
}
/* struct defining one row of our sketch */
typedef struct LossySketch
{
  unsigned _hash_func_index; /* which hash function */
  unsigned _b; /* number of counters or buckets for a hash function */
  char* identity; /* pointer to array of '_b' words */
  int* lossyCount; /* 1-D array of '_b' counts */

} LossySketch;

/* This function updates the local sketch */ 
int update_sketch( LossySketch* _sketch,
                    char hash_func_rand,
                    char* word,
                    unsigned log2range,
                    int f, int threshold)
{
  if (strlen(word) >= MAX_WORD_LENGTH)
    return -1;

  unsigned bucket = gethash( word, hash_func_rand, log2range );

  int* count_ptr = &((*_sketch).lossyCount[bucket]);
  int count;
  char* str_ptr = &((*_sketch).identity[bucket*MAX_WORD_LENGTH]);
  if (*count_ptr == -1)
  { /* if the counter is empty */
    strcpy (str_ptr, word);
    *count_ptr = f+1;
  }
  else
  { /* if counter is not empty */
    /* we update count based on comparison of strings */
    if (!strcmp(str_ptr, word)) /* strcmp returns 0 if equal */
    { /* if same word */
      (*count_ptr) += f;
      if ((*count_ptr) > (threshold)+10)
		return bucket;
    }
    else
    { /* if words are different */
		*count_ptr = *count_ptr - f;
      if (*count_ptr < 0)
      { /* if decreasing the counter makes it's value negative */
        /* replace previous word with new word and set counter */
        strcpy (str_ptr, word);
        *count_ptr = -*count_ptr;
      }
    }
  }
  return -1;
}
  
/* struct defining filter*/
typedef struct Filter
{
  unsigned _filtersize; /* size of filter */
  int _changed;
  int index;
  char* identity; /* pointer to array of '_filtersize' words */
  int* filter_newcount; /* 1-D array of '_filtersize' counts */
  int* filter_oldcount; /* 1-D array of '_filtersize' counts */
  int* fcounter;
  uint16_t* fhash;

} Filter;

typedef struct GlobalFilter
{
  unsigned _filtersize; /* size of filter */
  char* identity; /* pointer to array of '_filtersize' words */
  int* filter_newcount; /* 1-D array of '_filtersize' counts */
  int* fcounter;

} GlobalFilter;

// 128-bit vector
int find_min(Filter* _filter)
{
	const __m128i increment = _mm_set1_epi32(4);
	__m128i indices         = _mm_setr_epi32(0, 1, 2, 3);
	__m128i minindices      = indices;
	__m128i minvalues       = _mm_loadu_si128((__m128i*)((*_filter).filter_newcount));
	int index;
	int min_value ;

	for (size_t i=4; i < (*_filter)._filtersize; i += 4) 
	{
    indices = _mm_add_epi32(indices, increment);
    const __m128i values        = _mm_loadu_si128((__m128i*)((*_filter).filter_newcount + i));
    const __m128i lt            = _mm_cmpgt_epi32(minvalues,values);
    minindices = _mm_blendv_epi8(minindices, indices, lt);
    minvalues  = _mm_blendv_epi8(minvalues,values,lt);
    }
    
    int32_t values_array[4];
    uint32_t indices_array[4];

    _mm_storeu_si128((__m128i*)values_array, minvalues);
    _mm_storeu_si128((__m128i*)indices_array, minindices);

    index = indices_array[0];
    min_value = values_array[0];
    for (int i=1; i < 4; i++) {
        if (values_array[i] < min_value) {
            min_value = values_array[i];
            index = indices_array[i];
        } 
    }
    return index;
}
// 256-bit vector
/*int find_min(Filter* _filter)
{
	const __m256i increment = _mm256_set1_epi32(8);
	__m256i indices         = _mm256_setr_epi32(0, 1, 2, 3,4,5,6,7);
	__m256i minindices      = indices;
	__m256i minvalues       =  _mm256_loadu_si256((__m256i*)((*_filter).filter_newcount));
	int minindex;
	int min_value ;

	for (size_t i=8; i < (*_filter)._filtersize; i += 8) 
	{
    indices = _mm256_add_epi32(indices, increment);
    const __m256i values        = _mm256_loadu_si256((__m256i*)((*_filter).filter_newcount + i));
    const __m256i lt            = _mm256_cmpgt_epi32(minvalues,values);
    minindices = _mm256_blendv_epi8(minindices, indices, lt);
    minvalues  = _mm256_blendv_epi8(minvalues,values,lt);
    }
    
    int32_t values_array[8];
    uint32_t indices_array[8];

    _mm256_storeu_si256((__m256i*)values_array, minvalues);
    _mm256_storeu_si256((__m256i*)indices_array, minindices);

    minindex = indices_array[0];
    min_value = values_array[0];
    for (int i=1; i < 8; i++) {
        if (values_array[i] < min_value) {
            min_value = values_array[i];
            minindex = indices_array[i];
        } 
    }
   return minindex;
}*/

void update_filter( int tid,
					int num_hash_func,
					Filter* _filter,
					LossySketch* _sketch,
					char* hash_func_rands,
                    char* word,
                    unsigned log2range,
                    char hash_func_rand_fixed)
{
  int i;
  int j;
  int index;
  uint16_t key;
  int* f_counter = &((*_filter).fcounter[0]);
  
  if (strlen(word) >= MAX_WORD_LENGTH)
    return ; 
    
  key = (uint16_t)(gethash( word, hash_func_rand_fixed, log2range ));
  int bucket_num = (*_filter)._filtersize / 32 ;
  
  // 256-bit vector
 /* for (int i = 0; i < bucket_num; i++) 
  {
	const __m256i item = _mm256_set1_epi16((int)key);

	__m256i *keys_p = (__m256i *)((*_filter).fhash+ (i << 5));

	__m256i a_comp = _mm256_cmpeq_epi16(item, keys_p[0]);
	__m256i b_comp = _mm256_cmpeq_epi16(item, keys_p[1]);

    a_comp = _mm256_packs_epi16(a_comp, b_comp);
    a_comp = _mm256_permutevar8x32_epi32(a_comp, _mm256_setr_epi32(0,1, 4,5, 2,3, 6,7));


    int matched = _mm256_movemask_epi8(a_comp);

    if(matched != 0)
    {
		//return 32 if input is zero; 
		int matched_index = __builtin_ctz(matched)+(i << 5);
        (*_filter).filter_newcount[matched_index] += 1 ;
        return;
     }
 }*/
	// 128-bit vector
   for (int i = 0; i < bucket_num; i++)
   {
		const __m128i item = _mm_set1_epi16((int)key);

		__m128i *keys = (__m128i *)((*_filter).fhash+ (i << 5));

		__m128i a_comp = _mm_cmpeq_epi16(item, keys[0]);
		__m128i b_comp = _mm_cmpeq_epi16(item, keys[1]);
		__m128i c_comp = _mm_cmpeq_epi16(item, keys[2]);
		__m128i d_comp = _mm_cmpeq_epi16(item, keys[3]);

		a_comp = _mm_packs_epi16(a_comp, b_comp);
		c_comp = _mm_packs_epi16(c_comp, d_comp);

		uint16_t matched1 = _mm_movemask_epi8(a_comp);
		uint16_t matched2 = _mm_movemask_epi8(c_comp);
		uint32_t matched =  (static_cast<uint32_t>(matched2) << 16) 
								+ static_cast<uint32_t>(matched1);

		if(matched != 0)
		{
			int matched_index = __builtin_ctz(matched)+ (i << 5);
			(*_filter).filter_newcount[matched_index] += 1 ;
			return;
		}
	}
  
  if (*f_counter != (*_filter)._filtersize )
  {
	strcpy (&((*_filter).identity[(*f_counter) * MAX_WORD_LENGTH]), word);
	(*_filter).filter_newcount[*f_counter] = 1;
	(*_filter).filter_oldcount[*f_counter] = 0;
	(*f_counter)++;  
	
  }else
  {  
	  
	if ((*_filter)._changed == 1 )
	{
		(*_filter).index = find_min(&(*_filter));
		index = (*_filter).index;
		(*_filter)._changed = 0;
	}
	/* update the sketch*/  
	int update = -1;
	for (i = 0; i < num_hash_func; ++i)
	{
		//(*_filter).sketchcount += 1;
		update = update_sketch(&_sketch[tid * num_hash_func + i], hash_func_rands[i], word, log2range,1,(*_filter).filter_newcount[index]);  
		// update_sketch(&_sketch[tid * num_hash_func + i], hash_func_rands[i], word, log2range,1);  

		if (update > 0)
		{
			int delta1 = 0;
			(*_filter)._changed = 1;
			delta1 = (*_filter).filter_newcount[index] - (*_filter).filter_oldcount[index];
			
			for (j = 0; j < num_hash_func; ++j)
				int no_effect = update_sketch(&_sketch[tid * num_hash_func + j], hash_func_rands[j], &((*_filter).identity[index * MAX_WORD_LENGTH]), log2range,delta1,(*_filter).filter_newcount[index]); 
			
			(*_filter).filter_newcount[index] = _sketch[tid * num_hash_func + i].lossyCount[update];
			(*_filter).filter_oldcount[index] = (*_filter).filter_newcount[index];
			(*_filter).fhash[index] = (uint16_t)(gethash( word, hash_func_rand_fixed, log2range ));
			strcpy(&((*_filter).identity[index * MAX_WORD_LENGTH]), &_sketch[tid * num_hash_func + i].identity[update*MAX_WORD_LENGTH]);
			//(*_filter).filterupdate +=1;
			return;
			
		}
		
	}
	
	return ;
  }
  return;
}
/* Initiliazing filter */
void allocate_filter( Filter* filter,
                      const unsigned filter_range )
{
  int i;

  (*filter)._filtersize           = filter_range;
  (*filter)._changed = 1;
  (*filter).identity     = (char*) malloc(filter_range * MAX_WORD_LENGTH * sizeof(char));
  (*filter).filter_newcount   = (int* ) malloc(filter_range * sizeof(int));
  (*filter).filter_oldcount   = (int* ) malloc(filter_range * sizeof(int));
  (*filter).fhash   = (uint16_t* ) malloc(filter_range * sizeof(uint16_t));
  (*filter).fcounter          =(int* ) malloc(sizeof(int));
  
	if ( (*filter).identity == NULL ||
			 (*filter).filter_newcount == NULL ||
				(*filter).filter_oldcount == NULL ||
				(*filter).fcounter == NULL)
	{
		fprintf(stderr, "filter allocation error!\n");
		exit(EXIT_FAILURE);
	}
  /* set counts to -1 to indicate empty counter */
  for (i = 0; i < filter_range; ++i)
  {
    (*filter).filter_newcount[i] = -1;
    (*filter).filter_oldcount[i] = -1;
  }
  (*filter).fcounter[0] = 0;
}

void allocate_globalfilter( GlobalFilter* filter,
                      const unsigned filter_range,
                      int num_thread )
{
  int i;

  (*filter)._filtersize           = filter_range;
  (*filter).identity     = (char*) malloc(filter_range * num_thread * MAX_WORD_LENGTH * sizeof(char));
  (*filter).filter_newcount   = (int* ) malloc(filter_range * num_thread * sizeof(int));
  (*filter).fcounter          =(int* ) malloc(sizeof(int));
  
	if ( (*filter).identity == NULL ||
			 (*filter).filter_newcount == NULL ||
				(*filter).fcounter == NULL)
	{
		fprintf(stderr, "filter allocation error!\n");
		exit(EXIT_FAILURE);
	}

  (*filter).fcounter[0] = 0;
}

/* Frees a row of filter data structure */
void deallocate_filter( Filter* filter )
{
  free((*filter).identity);
  free((*filter).filter_newcount);
  free((*filter).filter_oldcount);
  free((*filter).fhash);
  free((*filter).fcounter);
}
void deallocate_globalfilter( GlobalFilter* filter )
{
  free((*filter).identity);
  free((*filter).filter_newcount);
  free((*filter).fcounter);
}

/* Initializing Sketch */
void allocate_sketch( LossySketch* sketch,
                      const unsigned range )
{
  int i;
  (*sketch)._b           = range;
  (*sketch).identity     = (char*) malloc(range*MAX_WORD_LENGTH*sizeof(char));
  (*sketch).lossyCount   = (int* ) malloc(range*sizeof(int));
	if ( (*sketch).identity == NULL ||
			 (*sketch).lossyCount == NULL )
	{
		fprintf(stderr, "LossySketch allocation error!\n");
		exit(EXIT_FAILURE);
	}
  /* set counts to -1 to indicate empty counter */
  for (i = 0; i < range; ++i)
    (*sketch).lossyCount[i] = -1;
}

/* Frees a row of topkapi sketch data structure */
void deallocate_sketch( LossySketch* sketch )
{
  free((*sketch).identity);
  free((*sketch).lossyCount);
}

void ascendingSwap(int i , int j , GlobalFilter* a)                                           //swap two values such that they appear in ascending order in the array
{
  if((*a).filter_newcount[i] > (*a).filter_newcount[j])
  {
	char* identity;
	identity = (char* )malloc(MAX_WORD_LENGTH * sizeof(char));
	int finalcount;
	finalcount = (*a).filter_newcount[i];
	strcpy(&identity[0], &(*a).identity[i * MAX_WORD_LENGTH]);
	strcpy(&(*a).identity[i * MAX_WORD_LENGTH], &(*a).identity[j * MAX_WORD_LENGTH]);
	strcpy(&(*a).identity[j * MAX_WORD_LENGTH], &identity[0]);
	(*a).filter_newcount[i] = (*a).filter_newcount[j];
	(*a).filter_newcount[j] = finalcount;
	free(identity);
  }
}

void decendingSwap(int i , int j , GlobalFilter* a)                                           //swap two values such that they appear in decending order in the array
{
  if((*a).filter_newcount[i] < (*a).filter_newcount[j])
  {
	char* identity;
	identity = (char* )malloc(MAX_WORD_LENGTH * sizeof(char));
	int finalcount;
	finalcount = (*a).filter_newcount[i];
	strcpy(&identity[0], &(*a).identity[i * MAX_WORD_LENGTH]);
	strcpy(&(*a).identity[i * MAX_WORD_LENGTH], &(*a).identity[j * MAX_WORD_LENGTH]);
	strcpy(&(*a).identity[j * MAX_WORD_LENGTH], &identity[0]);
	(*a).filter_newcount[i] = (*a).filter_newcount[j];
	(*a).filter_newcount[j] = finalcount;
	free(identity);
  }
}
    void bitonicSortFromBitonicSequence( int startIndex ,int lastIndex, int dir , GlobalFilter* ar )     //form a increaseing or decreasing array when a bitonic input is given to the function
    {
        if(dir == 1)
        {
            int counter = 0;                                                                    //counter to keep track of already swapped elements ,, parallelising this area results in poor performance due to overhead ,,need to fix
            int noOfElements = lastIndex - startIndex + 1;
            for(int j = noOfElements/2;j>0;j = j/2)
            {   counter =0;
                for(int i = startIndex ; i +j <= lastIndex ; i++)
                {
                        if(counter < j)
                        {
                            ascendingSwap(i,i+j,ar);
                            counter++;

                        }
                        else 
                        {
                            counter =0;
                            i = i+ j-1;
                            
                        }
                }
            }
        }
        else                                                                                    //decending sort
        {
            int counter = 0;
            int noOfElements = lastIndex - startIndex + 1;
            for(int j = noOfElements/2;j>0;j = j/2)
            {   counter =0;
                for(int i = startIndex ; i <= (lastIndex-j) ; i++)
                {
                        if(counter < j)
                        {
                            decendingSwap(i,i+j,ar);
                            counter++;

                        }
                        else 
                        {
                            counter =0;
                            i = i+ j-1;
                            
                        }
                }
            }
        }
    
    }
void bitonicSequenceGenerator(int startIndex , int lastIndex , GlobalFilter* ar)                         //generate a bitonic sequence  from a a random order
{
    int noOfElements = lastIndex - startIndex +1;
      for(int j = 2;j<=noOfElements;j = j*2)
            {   
                #pragma omp parallel for                                                         //parallel implementation results in most performance gains here
                for(int i=0;i<noOfElements;i=i+j)
                { 
                 if(((i/j)%2) ==0)                                                               //extra computation results in drastically lower performance ,need to fix
                 {
                     bitonicSortFromBitonicSequence(i,i+j-1,1,ar);
                 }   
                 else
                 {
                     bitonicSortFromBitonicSequence(i,i+j-1,0,ar);
                 }
                }
            }
}

int main()
{
  printf("Start\n");
  int i,j;
  /* Default Parameter values for filter */
  unsigned filter_range = 128; /* range of buckets for the filter */
  /* Default Parameter values for Sketch */
  unsigned range = 1024; /* range of buckets for the sketch */
  unsigned log2range = 10; /* log2 value of range */
  unsigned num_hash_func = 4; /* number of hash functions */
  int my_rank;
  
  /* number of threads*/
  int num_threads = 16;
  /* Data for filter */
  Filter* th_local_filter; /* array of thread local filter */
  GlobalFilter* th_global_filter; /*for saving global filter*/
  /* Data for Sketch */
  LossySketch* th_local_sketch; /* array of thread local sketches */
  /* Random numbers for hash functions */
  char* hash_func_rands;
  char* hash_func_rand_fixed;
  int rand_differ;
  srand(time(NULL));
  /* allocate memory to local filter */
  th_local_filter = (Filter* ) malloc(num_threads * sizeof(Filter));
  th_global_filter = (GlobalFilter* ) malloc(sizeof(GlobalFilter));
  /* allocate memory to local filter */             
  th_local_sketch = (LossySketch* ) malloc(num_hash_func * num_threads * sizeof(LossySketch));
  /*MPI variable*/
  int error = 0;
  double start_time, end_time;
  double total_time = 0.0;
  /* variables for file operation */
  char*  my_file;
  char   default_out_file[] = "topK.out"; /* default output file name */
  char*  output_file = &default_out_file[0]; /* used for storing TopK words */
  char*  str_buff[2]; /* use two buffers alternatively to do parallel read and computation */
  int    str_buff_write_id = 0;
  int    str_buff_read_id = 0;
  size_t read_size;
  size_t compute_size;
  FILE*  fp;
  int    file_end_flag = FALSE;
  int    do_compute_flag = TRUE;
  
  /* hash function specific different random number generartion */ 
  hash_func_rands = (char* )malloc(num_hash_func*sizeof(char));
  hash_func_rand_fixed = (char* )malloc(sizeof(char));

    for (i = 0; i < num_hash_func; ++i)
    {
      rand_differ = FALSE;
      hash_func_rands[i] = (char) (rand() % 47);
      while (!rand_differ)
      {
        rand_differ = TRUE;
        for (j = 0; j < i; ++j)
        {
          if (hash_func_rands[i] == hash_func_rands[j])
          {  
            rand_differ = FALSE;
            break;
          }
        }
        if (!rand_differ)
        {
          hash_func_rands[i] = (char) (rand() % 47);
        }
      }
    }
    
  *hash_func_rand_fixed = (char) (rand() % 47); 
  
    fprintf (stdout, "*************Parameter Values***********\n"
                     "Bucket Range: %d,  hash functions: %d\n"
                     "K: %d,  Number of threads: %d\n"
                     "****************************************\n",
                     range, num_hash_func, filter_range, num_threads);
    fprintf (stdout, "************Output file name************\n"
                     "%s\n"
                     "****************************************\n", 
                     output_file);
  
  /*openmp setting*/
  omp_set_num_threads( num_threads );
  omp_set_dynamic( 0 );
  start_time = MPI_Wtime();

/* Allocate and initialize filter variables */
#pragma omp parallel firstprivate(th_local_filter, filter_range)
  {
    int tid = omp_get_thread_num();
    int th_i;
    
    allocate_filter(&th_local_filter[tid], filter_range);
    
    for (th_i = 0; th_i < num_hash_func; ++th_i)
    {
      allocate_sketch( &th_local_sketch[tid*num_hash_func+th_i], range);
    }
    
  }
     /*end time */
    end_time = MPI_Wtime();
    total_time += (end_time - start_time); 
  
  /* File operations */
  fp = fopen64("finalmergedfile.txt","r");
    if (fp == NULL)
  {
    fprintf(stderr, "Error opening file!");
    error = 1;
  } 
  str_buff[0] = (char* )malloc(CHUNK_SIZE*sizeof(char));
  str_buff[1] = (char* )malloc(CHUNK_SIZE*sizeof(char));
  if (str_buff[0] == NULL || str_buff[1] == NULL)
  {
    fprintf(stderr, "Error allocating memory for reading files!");
    error = 1;
  }
  read_size = fread(str_buff[str_buff_write_id], 1, CHUNK_SIZE, fp);
  if (read_size != CHUNK_SIZE)
  {
    if (feof(fp))
      file_end_flag = TRUE;
    else
    {
      fprintf(stderr, "Error reading file!");
      error = 1;
    }
  }
  compute_size = read_size / num_threads;
  for (i = 0; i < num_threads; ++i)
    str_buff[str_buff_write_id][(i+1)*compute_size - 1] = '\0';
  str_buff_write_id ^= 0x1;
  
  /* read from file and update filter*/
    while (do_compute_flag)
  {
    if (!file_end_flag)
    {
      read_size = fread(str_buff[str_buff_write_id], 1, CHUNK_SIZE, fp);
      if (read_size != CHUNK_SIZE)
      {
        if (feof(fp))
          file_end_flag = TRUE;
        else
        {
          fprintf(stderr, "Error reading file!");
          exit(EXIT_FAILURE);
        }
      }
      for (i = 0; i < num_threads; ++i)
        str_buff[str_buff_write_id][(i+1)*compute_size - 1] = '\0';
      str_buff_write_id ^= 0x1;
    } else {
      do_compute_flag = FALSE;
    }
    /*start time */
	start_time = MPI_Wtime();
    omp_set_num_threads( num_threads );
    omp_set_dynamic( 0 );
#pragma omp parallel firstprivate(range, log2range,\
		num_hash_func,th_local_sketch, str_buff, hash_func_rands,filter_range, th_local_filter)
    { 
      int tid = omp_get_thread_num();
      char*  word;
      char*  prev_word_ptr;
    
      /* read words from the buffer one by one */
      word = strtok_r (&str_buff[str_buff_read_id][tid*compute_size], " \n", &prev_word_ptr);
      while (word != NULL)
      {
		update_filter(tid,num_hash_func,&th_local_filter[tid],th_local_sketch,hash_func_rands, word,log2range,*hash_func_rand_fixed); 
        /* we have a word */
        word = strtok_r (NULL, " \n", &prev_word_ptr);
      }
    }   
    /*end time */
    end_time = MPI_Wtime();
    total_time += (end_time - start_time); 
    
    compute_size = read_size / num_threads;
    str_buff_read_id ^= 0x1;
  }
  fclose(fp);
  
  //merged filter
  allocate_globalfilter(th_global_filter, filter_range, num_threads);
  
  for (j = 0; j < num_threads ; ++j)
  {
	for (i = 0; i < filter_range; ++i)
	{
		strcpy(&(*th_global_filter).identity[ (j * filter_range + i) * MAX_WORD_LENGTH] , &th_local_filter[j].identity[ i * MAX_WORD_LENGTH]);
		(*th_global_filter).filter_newcount[ j * filter_range + i] = (th_local_filter[j]).filter_newcount[i];
	}	
  }
   //start_time = MPI_Wtime();

  for (j = 0; j < num_threads * filter_range ; ++j)
  {
	  for (i = j; i < num_threads * filter_range; ++i)
	  {
		  if ((*th_global_filter).filter_newcount[i] != -1)
		  {
			if (!strcmp(&(*th_global_filter).identity[ j * MAX_WORD_LENGTH], &(*th_global_filter).identity[ i * MAX_WORD_LENGTH]))
			{
			  (*th_global_filter).filter_newcount[j] += (*th_global_filter).filter_newcount[i];
			  (*th_global_filter).filter_newcount[i] = -1;
			}
		  }
	  }
  }
    
   start_time = MPI_Wtime();

    fp = fopen(output_file,"w");
    if (fp == NULL)
    {
      fprintf(stderr, "Error opening output file!\nFilename:%s\n",
          output_file);
      fprintf(stderr, "Error opening output file!\nFilename:%s\n",
          output_file);
      fprintf(stderr, "Printing the TopK words to stdout!\n");
      fp = stdout;
    } 
    
    bitonicSequenceGenerator(0,(num_threads * filter_range)-1,th_global_filter);
    
   for (j = ( num_threads * filter_range)-1; j >= 0  ; --j)
   {
	   if ((*th_global_filter).filter_newcount[j] != -1)
	   
			fprintf(fp, "%s %d\n", &(*th_global_filter).identity[ j * MAX_WORD_LENGTH], 
                (*th_global_filter).filter_newcount[j]);
    }

   
    end_time = MPI_Wtime();
    total_time += (end_time - start_time); 
    printf("Elapsed time: %fseconds\n", total_time); 
    printf("Sort time: %fseconds\n", (end_time - start_time));
 
  
    /*deallocate filter*/
    for (i = 0; i  < num_threads; ++i)
	{
      deallocate_filter( &th_local_filter[i] );
	}

    /*deallocate sketch*/
   for (i = 0; i  < num_threads; ++i)
	{
		for (j = 0; j < num_hash_func; ++j)
		{
			deallocate_sketch( &th_local_sketch[i*num_hash_func + j] );
		}
	}
  
  free(th_local_filter);
  free(th_global_filter);
  free(th_local_sketch);
  free(hash_func_rands);
  free(hash_func_rand_fixed);
  free(str_buff[0]);
  free(str_buff[1]);
  
  printf("**************************************** \nFinish");
  
  return 0;
}
