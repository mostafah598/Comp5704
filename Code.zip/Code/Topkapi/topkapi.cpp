#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <math.h>
#include <map>
/*#include <mpi.h>*/
#include <omp.h>
#include "/lib/x86_64-linux-gnu/openmpi/include/mpi.h"
#include <x86intrin.h>
#include <bmiintrin.h>
#include <time.h>
#include <chrono>
using namespace std;
using namespace std::chrono;

//-----------------------------------------------------------------------------
// MurmurHash3 was written by Austin Appleby, and is placed in the public
// domain. The author hereby disclaims copyright to this source code.

#define	FORCE_INLINE inline __attribute__((always_inline))

inline uint32_t rotl32 ( uint32_t x, int8_t r )
{
  return (x << r) | (x >> (32 - r));
}

uint32_t rotl32 ( uint32_t x, int8_t r ); /* instantiation */

#define	ROTL32(x,y)	rotl32(x,y)

//-----------------------------------------------------------------------------
// Block read - if your platform needs to do endian-swapping or can only
// handle aligned reads, do the conversion here

FORCE_INLINE uint32_t getblock32 ( const uint32_t * p, int i )
{
  return p[i];
}

//-----------------------------------------------------------------------------
// Finalization mix - force all bits of a hash block to avalanche

FORCE_INLINE uint32_t fmix32 ( uint32_t h )
{
  h ^= h >> 16;
  h *= 0x85ebca6b;
  h ^= h >> 13;
  h *= 0xc2b2ae35;
  h ^= h >> 16;

  return h;
}

//-----------------------------------------------------------------------------

void MurmurHash3_x86_32 ( const void * key, int len,
                          uint32_t seed, void * out )
{
  const uint8_t * data = (const uint8_t*)key;
  const int nblocks = len / 4;

  uint32_t h1 = seed;

  const uint32_t c1 = 0xcc9e2d51;
  const uint32_t c2 = 0x1b873593;

  //----------
  // body

  const uint32_t * blocks = (const uint32_t *)(data + nblocks*4);

  for(int i = -nblocks; i; i++)
  {
    uint32_t k1 = getblock32(blocks,i);

    k1 *= c1;
    k1 = ROTL32(k1,15);
    k1 *= c2;
    
    h1 ^= k1;
    h1 = ROTL32(h1,13); 
    h1 = h1*5+0xe6546b64;
  }

  //----------
  // tail

  const uint8_t * tail = (const uint8_t*)(data + nblocks*4);

  uint32_t k1 = 0;

  switch(len & 3)
  {
  case 3: k1 ^= tail[2] << 16;
  case 2: k1 ^= tail[1] << 8;
  case 1: k1 ^= tail[0];
          k1 *= c1; k1 = ROTL32(k1,15); k1 *= c2; h1 ^= k1;
  };

  //----------
  // finalization

  h1 ^= len;

  h1 = fmix32(h1);

  *(uint32_t*)out = h1;
} 


unsigned gethash( const char* word, char hash_rand, unsigned log2range)
{
  unsigned hash;
  uint32_t seed = 0x9747b28c;
  size_t len = strlen( word ) + 1;
  char str_to_hash[len];
  strcpy( str_to_hash, word ) ;
  /* hash_rand is hash function specific random value, 
   * we put it at the end of the string */
  str_to_hash[len-1] = hash_rand;
  MurmurHash3_x86_32( str_to_hash, len*sizeof(char), seed, &hash );
  /* Now, we shift bits to limit the 
   * hash value  within log2range */
  hash = hash << (32 - log2range);
  hash = hash >> (32 - log2range);
  return hash;
}

#define MAX_WORD_LENGTH 16

/* struct defining one row of our sketch */
typedef struct LossySketch
{
  unsigned _hash_func_index; /* which hash function */
  unsigned _b; /* number of counters or buckets for a hash function */
  char* identity; /* pointer to array of '_b' words */
  /* we can do this with because we are assigning fixed length of
   * memories for each word. It is efficient and easy to handle.
   * In our case, we assign 16Bytes, i.e. we limit our word 
   * length to 16 characters.
   */
  int* lossyCount; /* 1-D array of '_b' counts */
  /* Cache line size assumed to be 64Byte.
   * Each hash function has 4 * 4 Bytes of elements
   * in this data structure. Assuming 4 hash functions 
   * in each thread, there is no false sharing */
} LossySketch;

/* This function updates the local sketch 
 * based on input word
 */ 
 
void update_sketch( LossySketch* _sketch,
                    char hash_func_rand,
                    char* word,
                    unsigned log2range)
{
  if (strlen(word) >= MAX_WORD_LENGTH)
    return ;

  unsigned bucket = gethash( word, hash_func_rand, log2range );
  int* count_ptr = &((*_sketch).lossyCount[bucket]);
  int count;
  char* str_ptr = &((*_sketch).identity[bucket*MAX_WORD_LENGTH]);
  if (*count_ptr == -1)
  { /* if the counter is empty */
    strcpy (str_ptr, word);
    *count_ptr = 1;
  }
  else
  { /* if counter is not empty */
    /* we update count based on comparison of strings */
    if (!strcmp(str_ptr, word)) /* strcmp returns 0 if equal */
    { /* if same word */
      (*count_ptr) ++;
    }
    else
    { /* if words are different */
      if (--(*count_ptr) < 0)
      { /* if decreasing the counter makes it's value negative */
        /* replace previous word with new word and set counter */
        strcpy (str_ptr, word);
        *count_ptr = 1;
      }
    }
  }
  
}

/* This function merges thread local sketches to
 * create the final sketch for a node
 */
void local_merge_sketch( LossySketch*   LCMS,
                         const unsigned num_local_copies,
                         const unsigned num_hash_func,
                         const unsigned hash_func_index )
{
  char* word[num_local_copies];
  int count[num_local_copies];
  unsigned i, j, k, diff_words;
  int max_selected;
  char* current_word;
  int max_count;
  unsigned range = LCMS[0]._b;

  for (i = 0; i < range; ++i)
  {
    word[0] = &(LCMS[hash_func_index].identity[i*MAX_WORD_LENGTH]);
    count[0] = LCMS[hash_func_index].lossyCount[i];
    diff_words = 1;
    for (j = 1; j < num_local_copies; ++j)
    {
      current_word = &(LCMS[j*num_hash_func+hash_func_index].identity[i*MAX_WORD_LENGTH]);
      for ( k = 0; k < diff_words; ++k)
      {
        if (!strcmp(current_word, word[k]) &&
            LCMS[j*num_hash_func+hash_func_index].lossyCount[i] != (-1))
        {
          /* if same word */
          count[k] += LCMS[j*num_hash_func+hash_func_index].lossyCount[i];
          break;
        }
      }
      if (k == diff_words)
      {
        word[diff_words] = current_word;
        count[diff_words] = LCMS[j*num_hash_func+hash_func_index].lossyCount[i];
        diff_words++;
      }
    }
    max_count = -1;
    max_selected = 0;
    k = 0;
    for (j = 0; j < diff_words; ++j)
    {
      if (count[j] != (-1))
      {
        if (max_selected)
        {
          if (count[j] > max_count)
          {
            max_count = (count[j] - max_count);
            k = j;
          } else {
            max_count -= count[j];
          }
        } else {
          max_count = count[j];
          k = j;
          max_selected = 1;
        }
      }
    }
    if (k != 0)
    {
      strcpy(word[0], word[k]);
    }
    LCMS[hash_func_index].lossyCount[i] = max_count;
  }
}

/* Reads data in 64MB chunks */
#define CHUNK_SIZE (64*1024*1024)
#define TRUE 1
#define FALSE 0

/* Allocates a row of topkapi sketch data structure */
void allocate_sketch( LossySketch* sketch,
                      const unsigned range )
{
  int i;
  (*sketch)._b           = range;
  (*sketch).identity     = (char*) malloc(range*MAX_WORD_LENGTH*sizeof(char));
  (*sketch).lossyCount   = (int* ) malloc(range*sizeof(int));
	if ( (*sketch).identity == NULL ||
			 (*sketch).lossyCount == NULL )
	{
		fprintf(stderr, "LossySketch allocation error!\n");
		exit(EXIT_FAILURE);
	}
  /* set counts to -1 to indicate empty counter */
  for (i = 0; i < range; ++i)
    (*sketch).lossyCount[i] = -1;
}

/* Frees a row of topkapi sketch data structure */
void deallocate_sketch( LossySketch* sketch )
{
  free((*sketch).identity);
  free((*sketch).lossyCount);
}


int main(int argc, char* argv[])
{
  printf("Start\n");
  int i, j;
  /* Default Parameter values for Sketch */
  unsigned range = 1024; /* range of buckets for the sketch */
  unsigned log2range = 10; /* log2 value of range */
  unsigned num_hash_func = 4; /* number of hash functions */
  unsigned K = 128; /* Top K */
  unsigned frac_epsilon = 10*K; /* error margin */
  
  
  /* Data for Sketch */
  LossySketch* th_local_sketch; /* array of thread local sketches */
  LossySketch* node_final_sketch; /* final sketch in a node after merging thread local sketches */
  
  /* Random numbers for hash functions */
  char* hash_func_rands;
  int rand_differ;
  srand(time(NULL));
  
   /* Time */

  /* Data structures for sorting the heavy hitters to find topK */
  std::map<int,int> topk_words;
  std::map<int,int>::reverse_iterator rit;

  /* variables for file operation */
  char*  my_file;
  char   default_out_file[] = "topK.out"; /* default output file name */
  char*  output_file = &default_out_file[0]; /* used for storing TopK words */
  char*  str_buff[2]; /* use two buffers alternatively to do parallel read and computation */
  int    str_buff_write_id = 0;
  int    str_buff_read_id = 0;
  size_t read_size;
  size_t compute_size;
  FILE*  fp;
  int    file_end_flag = FALSE;
  int    do_compute_flag = TRUE;

  /* variables for OpenMP */
  int num_threads = 16;
  /*omp_get_num_procs(); /* default to number of procs available */

  /* variables for MPI */
  int num_nodes;
  int my_rank;
  int provided_threading;
  int error = 0;
  int reduced_error = 0;
  double start_time, end_time;
  double total_time = 0.0;

  /* printing the execution configuration */

    fprintf (stdout, "*************Parameter Values***********\n"
                     "Bucket Range: %d, hash functions: %d\n"
                     "K: %d, Number of threads: %d\n"
                     "****************************************\n",
                     range, num_hash_func, K, num_threads);
    fprintf (stdout, "************Output file name************\n"
                     "%s\n"
                     "****************************************\n", 
                     output_file);
 
  /* hash function specific different random number generartion */ 
  hash_func_rands = (char* )malloc(num_hash_func*sizeof(char));
  if (my_rank == 0)
  {
    for (i = 0; i < num_hash_func; ++i)
    {
      rand_differ = FALSE;
      hash_func_rands[i] = (char) (rand() % 47);
      while (!rand_differ)
      {
        rand_differ = TRUE;
        for (j = 0; j < i; ++j)
        {
          if (hash_func_rands[i] == hash_func_rands[j])
          {  
            rand_differ = FALSE;
            break;
          }
        }
        if (!rand_differ)
        {
          hash_func_rands[i] = (char) (rand() % 47);
        }
      }
    }
  }

  /* File operations */
  fp = fopen64("finalmergedfile.txt","r");
  if (fp == NULL)
  {
    fprintf(stderr, "Error opening file!\nNode:%d, Filename:%s\n",
        my_rank, my_file);
    error = 1;
  } 

  str_buff[0] = (char* )malloc(CHUNK_SIZE*sizeof(char));
  str_buff[1] = (char* )malloc(CHUNK_SIZE*sizeof(char));
  if (str_buff[0] == NULL || str_buff[1] == NULL)
  {
    fprintf(stderr, "Error allocating memory for reading files!\nNode:%d, " 
        "Filename:%s\n", my_rank, my_file);
    error = 1;
  }

  read_size = fread(str_buff[str_buff_write_id], 1, CHUNK_SIZE, fp);
  if (read_size != CHUNK_SIZE)
  {
    if (feof(fp))
      file_end_flag = TRUE;
    else
    {
      fprintf(stderr, "Error reading file!\nNode:%d, "
          "Filename:%s\n", my_rank, my_file);
      error = 1;
    }
  }

  compute_size = read_size / num_threads;
  for (i = 0; i < num_threads; ++i)
    str_buff[str_buff_write_id][(i+1)*compute_size - 1] = '\0';
  str_buff_write_id ^= 0x1;


  th_local_sketch = (LossySketch* ) malloc(num_hash_func*num_threads*
                                             sizeof(LossySketch));
  node_final_sketch = th_local_sketch; /* represents the first 
       num_hash_func number of sketches from th_local_sketch array */

  omp_set_num_threads( num_threads );
  omp_set_dynamic( 0 );
  
#pragma omp parallel firstprivate(th_local_sketch, range, num_hash_func)
  {
    int tid = omp_get_thread_num();
    int th_i;
    /* Allocate and initialize sketch variables */
    for (th_i = 0; th_i < num_hash_func; ++th_i)
    {
      allocate_sketch( &th_local_sketch[tid*num_hash_func+th_i], range);
    }
  }

  //auto start = high_resolution_clock::now();
  while (do_compute_flag)
  {
    if (!file_end_flag)
    {
      read_size = fread(str_buff[str_buff_write_id], 1, CHUNK_SIZE, fp);
      if (read_size != CHUNK_SIZE)
      {
        if (feof(fp))
          file_end_flag = TRUE;
        else
        {
          fprintf(stderr, "Error reading file!\nNode:%d, "
                    "Filename:%s\n", my_rank, my_file);
          exit(EXIT_FAILURE);
        }
      }
      for (i = 0; i < num_threads; ++i)
        str_buff[str_buff_write_id][(i+1)*compute_size - 1] = '\0';
      str_buff_write_id ^= 0x1;
    } else {
      do_compute_flag = FALSE;
    }
	/*start time */
	start_time = MPI_Wtime();
    omp_set_num_threads( num_threads );
    omp_set_dynamic( 0 );
    
#pragma omp parallel firstprivate(range, log2range,\
    num_hash_func, th_local_sketch, str_buff, hash_func_rands) private (i)
    { 
      int tid = omp_get_thread_num();
      int count;

      char*  word;
      char*  prev_word_ptr;
    
      /* read words from the buffer one by one */
      word = strtok_r (&str_buff[str_buff_read_id][tid*compute_size], " \n", &prev_word_ptr);
      while (word != NULL)
      {
        /* we have a word */
        for (i = 0; i < num_hash_func; ++i)
           update_sketch( &th_local_sketch[tid * num_hash_func + i], hash_func_rands[i], word, log2range);
        word = strtok_r (NULL, " \n", &prev_word_ptr);
      }
    }    
    /*end time */
    end_time = MPI_Wtime();
    total_time += (end_time - start_time);
    
    compute_size = read_size / num_threads;
    str_buff_read_id ^= 0x1;
  }
  fclose(fp);

  /* Now merge thread local sketches to produce final sketch for a node */
  start_time = MPI_Wtime();
  
  for (i = 0; i < num_hash_func; ++i)
    local_merge_sketch(th_local_sketch, num_threads, num_hash_func, i);
    
   end_time = MPI_Wtime();
   total_time += (end_time - start_time);

  
  /* Print TopK words */  
  if (my_rank == 0)
  {
    int num_heavy_hitter = 0;
    int count;
    char* str;
    int id;
    int* is_heavy_hitter = (int* )malloc(range*sizeof(int));
    int threshold = (int) ((range/K) - (range/frac_epsilon));
    //int threshold = 1;
    fp = fopen(output_file,"w");
    if (fp == NULL)
    {
      fprintf(stderr, "Error opening output file!\nFilename:%s\n",
          output_file);
      fprintf(stderr, "Error opening output file!\nFilename:%s\n",
          output_file);
      fprintf(stderr, "Printing the TopK words to stdout!\n");
      fp = stdout;
    } 
   start_time = MPI_Wtime();

#pragma omp parallel for firstprivate(threshold,\
    num_hash_func, log2range, is_heavy_hitter, hash_func_rands) private(j, count, str, id)
    for (i = 0; i < range; ++i)
    {
      is_heavy_hitter[i] = FALSE;
      for (j = 0; j < num_hash_func; ++j)
      {
        if ( j == 0)
        {
          str = &node_final_sketch[0].identity[i*MAX_WORD_LENGTH];
          count = node_final_sketch[0].lossyCount[i];
          if (count >= threshold)
          {
            is_heavy_hitter[i] = TRUE;
          }
        } else {
          id = gethash( str, hash_func_rands[j], log2range );
          if (strcmp(&node_final_sketch[j].identity[id*MAX_WORD_LENGTH], str) != 0)
          {
            continue;
          } else if (node_final_sketch[j].lossyCount[id] >= threshold)
          {
            is_heavy_hitter[i] = TRUE;
          }
          if (node_final_sketch[j].lossyCount[id] > count)
            count = node_final_sketch[j].lossyCount[id];
        }
      }
      node_final_sketch[0].lossyCount[i] = count;
    }
    

    for (i = 0; i < range; ++i)
    {
      if (is_heavy_hitter[i])
      {
        num_heavy_hitter ++;
        topk_words.insert( std::pair<int,int>(node_final_sketch[0].lossyCount[i], i) );
      }
    }

    for (i = 0, rit = topk_words.rbegin(); 
          (i < K) && (rit != topk_words.rend()); 
            ++i, ++rit)
    {
      j = rit->second;
      fprintf(fp, "%s %d\n", &node_final_sketch[0].identity[j*MAX_WORD_LENGTH], 
                rit->first);
    }

    if (fp != stdout) fclose(fp);
    /* free memories */
    free(is_heavy_hitter);
  }
  
  	end_time = MPI_Wtime();
	total_time += (end_time - start_time);
    printf("Elapsed time: %fseconds\n", total_time);
    
  for (i = 0; i  < num_threads; ++i)
  {
    for (j = 0; j < num_hash_func; ++j)
    {
      deallocate_sketch( &th_local_sketch[i*num_hash_func + j] );
    }
  }
  free(th_local_sketch);
  free(str_buff[0]);
  free(str_buff[1]);
  free(hash_func_rands);
  
  printf("**************************************** \nFinish");
  
  return 0;
}
