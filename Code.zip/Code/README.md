
This is a C++ implementaion of "Topkapi","Asketch" and "Proposed method" algorithms.


This implementation finds Top-K frequent words from text data.
It supports multi-threaded execution using OpenMP and SIMD Intrinsic using SSE and AVX.

## Prerequisites
- GNU Compiler Collection (GCC)
- OpenMP API


## Data
Dataset is from Gutenberg Project. 
Download Data file from the below link:
https://drive.google.com/file/d/16IyNPFwCAasKSDffRPi1y3GfnjAABHhc/view?usp=sharing

## How to Run
Copy dataset file to the current folder of each algorithm code and run the code with C++ platform such as Geany.

